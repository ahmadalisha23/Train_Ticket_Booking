package money;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter({ "/getAllStations", "/getTrains", "/BookServlet", "/logout" }) // Filtering these endpoints
public class AuthFilter implements Filter {

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpReq = (HttpServletRequest) req;
		HttpServletResponse httpRes = (HttpServletResponse) res;

		HttpSession session = httpReq.getSession(false); // Don't create a new session if it doesn't exist
		String isLoggedIn = session != null ? (String) session.getAttribute("LOGGEDIN") : null;

		if (isLoggedIn == null || !isLoggedIn.equals("YES")) {
			// If not logged in, redirect to login page
			httpRes.sendRedirect("login.html");
		} else {
			// If logged in, continue with the request
			chain.doFilter(req, res); // Pass the request to the next filter or target servlet
		}
	}
}
